from test_pyenv import TestPyenvBase


class TestPyenvFeatureUninstall(TestPyenvBase):
    pass

